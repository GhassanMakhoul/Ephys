import array
import xipppy_capi as _c
import ctypes
from .exception import check, XippPyException, XippPyDisconnect, error_string

class Button:
    STOP_STIM = _c.XL_BUTTON_STOP_STIM
    EVENT = _c.XL_BUTTON_EVENT
    F1 = _c.XL_BUTTON_F1
    F2 = _c.XL_BUTTON_F2

class Led:
    EVENT =  _c.XL_LED_EVENT
    F1 = _c.XL_LED_F1
    F2 = _c.XL_LED_F2
    PORTA = _c.XL_LED_PORTA
    PORTB = _c.XL_LED_PORTB
    PORTC = _c.XL_LED_PORTC
    PORTD = _c.XL_LED_PORTD


def button_get(button):
    val = ctypes.c_int()
    check(_c.xl_button_get_count(ctypes.addressof(val), button))
    return int(val.value)


def button_monitor(button, value):
    check(_c.xl_button_set_monitor(int(value), button))


def led_get(led):
    val = ctypes.c_int()
    check(_c.xl_led(ctypes.addressof(val), led))
    return bool(val.value)


def led_set(led, value):
    check(_c.xl_led_set(int(value), led))


def led_monitor(led, value):
    check(_c.xl_led_set_monitor(int(value), led))


# audio
def play_audio_tone(frequency, duration):
    """
    This will set and play the requested audio tone with provided frequency (Hz)
    and duration (mS).
    if you request a new tone while the old tone is playing the property will be
    overwritten and new tone will be played.
    :param frequency: beep frequency(Hz)
    :param duration: beep duration (mS)
    """
    freq = array.array('I', [frequency])
    (freq_ptr, _) = freq.buffer_info()

    dur = array.array('I', [duration])
    (dur_ptr, _) = dur.buffer_info()

    check(_c.xl_audio_tone_set(freq_ptr,dur_ptr),
          "Failed to set audion tone")


def processor_check_errors():
    return _c.xl_error_check()

def processor_get_errors():
    return _c.xl_py_error_getall()


class ConnectionPolicy:
    DEFAULT         = _c.XL_CONNECT_POLICY_DEFAULT
    PREFER_WIRED    = _c.XL_CONNECT_POLICY_PREFER_WIRED
    PREFER_WIRELESS = _c.XL_CONNECT_POLICY_PREFER_WIRELESS
    WIRED_ONLY      = _c.XL_CONNECT_POLICY_WIRED_ONLY
    WIRELESS_ONLY   = _c.XL_CONNECT_POLICY_WIRELESS_ONLY


class ConnectionType:
    DEFAULT = _c.XL_CONNECT_TYPE_DEFAULT
    TCP     = _c.XL_CONNECT_TYPE_TCP
    UDP     = _c.XL_CONNECT_TYPE_UDP


def processor_status(*, connection_policy = None, timeout = None):
    default = _c.XL_DEFAULT_STATUS_CONNECTION_OPTIONS
    opts = _c.XippConnectionOptions()
    opts.policy = default.policy
    opts.type = default.type
    opts.timeout = default.timeout

    if connection_policy:
        opts.policy = int(connection_policy)

    if timeout:
        opts.timeout = int(timeout)

    val = ctypes.c_int()
    check(_c.xl_processor_status(ctypes.addressof(val), opts))

    return bool(val.value)


def processor_restart():
    r = _c.xl_processor_restart_software()
    if r != 0:
        raise XippPyException(error_string(r))

    raise XippPyDisconnect()
