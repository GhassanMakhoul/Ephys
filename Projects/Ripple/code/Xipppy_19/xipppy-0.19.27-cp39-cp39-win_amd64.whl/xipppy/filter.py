import array
import ctypes
import itertools

import xipppy_capi as _c
from .exception import check


class SosStage:
    """
    Coefficients for one stage of a digital filter

    the coefficients are b0, b1, a1, and a2 in that order
    """

    def __init__(self, *args, **kwargs):
        self.b0 = float(0)
        self.b1 = float(0)
        self.a1 = float(0)
        self.a2 = float(0)

        if len(args) == 0:
            pass
        elif len(args) == 1:
            val = args[0]
            if isinstance(val, _c.SosStage_t):
                self.b0 = val.b0
                self.b1 = val.b1
                self.a1 = val.a1
                self.a2 = val.a2
            else:
                raise TypeError('Invalid initializer for SosStage')
        elif len(args) == 4:
            self.b0 = float(args[0])
            self.b1 = float(args[1])
            self.a1 = float(args[2])
            self.a2 = float(args[3])
        else:
            raise TypeError('Invalid initializer for SosStage')

    def to_SosStage_t(self):
        """
        convert SosStage into the SosStage_t required by xipplib
        """

        s = _c.SosStage_t()
        s.b0 = self.b0
        s.b1 = self.b1
        s.a1 = self.a1
        s.a2 = self.a2
        return s

    def __str__(self):
        return '<SosStage b0: {} b1: {} a1: {} a2: {}>'.format(
            self.b0, self.b1, self.a1, self.a2)


class SosFilterDesc:
    def __init__(self, *args, **kwargs):
        self.label = ''
        self.center = float(0)
        self.lowCutoff = float(0)
        self.highCutoff = float(0)
        self.centerOrder = int(0)
        self.centerFlags = int(0)
        self.lowOrder = int(0)
        self.lowFlags = int(0)
        self.highOrder = int(0)
        self.highFlags = int(0)
        self.stages = []

        if len(args) == 1:
            val = args[0]
            if isinstance(val, _c.SosFilterDesc_t):
                self.label = val.label
                self.center = val.center
                self.lowCutoff = val.lowCutoff
                self.highCutoff = val.highCutoff
                self.centerOrder = val.centerOrder
                self.centerFlags = val.centerFlags
                self.lowOrder = val.lowOrder
                self.lowFlags = val.lowFlags
                self.highOrder = val.highOrder
                self.highFlags = val.highFlags

                for i in range(val.numStages):
                    self.stages.append(SosStage(val.get_stage(i)))
            else:
                raise TypeError('Invalid initializer for SosDesc')

    @property
    def numStages(self):
        return len(self.stages)

    def to_SosFilterDesc_t(self):
        f = _c.SosFilterDesc_t(self.numStages)

        f.label = self.label
        f.center = self.center
        f.lowCutoff = self.lowCutoff
        f.highCutoff = self.highCutoff
        f.centerOrder = self.centerOrder
        f.centerFlags = self.centerFlags
        f.lowOrder = self.lowOrder
        f.lowFlags = self.lowFlags
        f.highOrder = self.highOrder
        f.highFlags = self.highFlags

        for i in range(self.numStages):
            f.set_stage(i, self.stages[i].to_SosStage_t())

        f.numStages = self.numStages
        f.maxStages = self.numStages
        return f


def filter_list_names(elec, max_names=32):
    """
    List available filter types for a given electrode.

    Arguments:
        elec: electrode ID
        max_names: maximum number of type strings to output. Any more than this
                 number will be truncated.
    """
    data = array.array('b', itertools.repeat(0, max_names * _c.STRLEN_LABEL))
    (ptr, _) = data.buffer_info()

    n = check(_c.xl_filter_list_names(ptr, max_names, elec),
              "Error getting filters names for {}".format(elec))
    ret = []
    for i in range(n):
        addr = ptr + i * _c.STRLEN_LABEL
        s = ctypes.string_at(addr)
        ret.append(s.decode('utf-8'))

    return ret


def filter_list_selection(elec, filter_type):
    """
    Get the selected filter of a type for a specified electrode.

    Returns a tuple (sel, nfilt) where sel is the number of the selected filter
    and nfilt is the number of filters matching the input parameters.

    Arguments:
        elec: electrode ID
        filter_type: string
    """
    buf = array.array('i', [0])
    (ptr, _) = buf.buffer_info()

    n = check(_c.xl_filter_list_selection(ptr, elec, filter_type))
    return buf[0], n


def filter_set(elec, filter_type, filter_index):
    """
    Select a filter in some fashion.

    Arguments:
        elec: electrode ID
        filter_type: string
        filter_index: integer
    """
    return check(_c.xl_filter_set(elec, filter_type, filter_index))


def _filter_get_desc(elec, filter_type, filter_index):
    """
    Return the SosFilter describing the requested filter, or None.

    Arguments:
        elec: electrode ID
        filter_type: string
        filter_index: integer
    """
    return _c.xl_filter_get_desc(elec, filter_type, filter_index)


def filter_get_desc(elec, filter_type, filter_index):
    """
    Return the SosFilter describing the requested filter, or None.

    Arguments:
        elec: electrode ID
        filter_type: string
        filter_index: integer
    """
    f = _c.xl_filter_get_desc(elec, filter_type, filter_index)
    if f is None:
        raise RuntimeError('Unable to get filter descriptor')
    return SosFilterDesc(f)


def filter_set_custom(elec, filter_type, filter_desc):
    """
    Set a custom filter on the specified electrode.

    Arguments:
        elec: electrode ID
        filter_type: string
        filter_desc: SosFilterDesc describing the new filter
    """

    if isinstance(filter_desc, _c.SosFilterDesc_t):
        return check(_c.xl_filter_set_custom(elec, filter_type, filter_desc))
    elif isinstance(filter_desc, SosFilterDesc):
        return check(
            _c.xl_filter_set_custom(
                elec, filter_type, filter_desc.to_SosFilterDesc_t()))
    else:
        raise ValueError(
            'Filter descriptor must be instance of SosFilterDesc_t')
